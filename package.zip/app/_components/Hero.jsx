"use client";

import React, { useState } from "react";

function Hero() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-100">
      {/* Left Side - Image */}
      <div className="flex-1 flex items-center justify-center bg-gray-200 p-6">
        <img
          src="/g1.png" // Replace with your image path
          alt="Register Illustration"
          className="max-w-full w-[70%] md:w-[60%] lg:w-[50%]"
        />
      </div>

      {/* Right Side - Banner */}
      <div className="flex-1 flex items-center justify-center bg-gray-200 p-8">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-3xl font-bold text-left text-gray-800 mb-8">
          Welcome to <span className="text-purple-600"><br/>Unstop</span>
          </h2>

          {/* Social Login Buttons */}
          <div className="space-y-4 mb-8">
            <button className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <img src="/go.svg" alt="Google" className="w-6 h-6" />
              <span className="text-gray-700 font-bold">Sign Up with Google</span>
            </button>
            <button className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors text-white">
              <img src="/fa.svg" alt="Facebook" className="w-6 h-6" />
              <span className="font-bold">Sign Up with Facebook</span>
            </button>
          </div>

          <div className="relative flex items-center justify-center mb-8">
            <div className="border-t border-gray-300 flex-grow"></div>
            <span className="px-4 text-gray-500 bg-white">OR</span>
            <div className="border-t border-gray-300 flex-grow"></div>
          </div>

          {/* Registration Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div className="relative">
              <img
                src="/account_circle.svg"
                alt="Account"
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
              />
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                placeholder="Full Name"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            {/* Email */}
            <div className="relative">
              <img
                src="/mail.svg"
                alt="Mail"
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
              />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="Email"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            {/* Password */}
            <div className="relative">
              <img
                src="/key.svg"
                alt="Key"
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
              />
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="Password"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            {/* Confirm Password */}
            <div className="relative">
              <img
                src="/key.svg"
                alt="Key"
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
              />
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                placeholder="Confirm Password"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2">
                <input type="checkbox" className="text-purple-600" />
                <span>I agree to the Terms and Conditions</span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
            >
              Register
            </button>
          </form>

          <div className="mt-6 text-sm text-center text-gray-600">
            Already have an account?{" "}
            <a href="#" className="text-purple-600 hover:underline">
              Login
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Hero;
